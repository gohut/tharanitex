import homeContent from "@/data/homeContent";

export default function WhySection() {
  const { whyTharani } = homeContent;

  return (
    <section className="bg-[#fbf3e6] px-6 py-20 sm:px-8 lg:px-12 lg:py-28">
      <div className="mx-auto grid max-w-[1180px] gap-14 lg:grid-cols-[1.08fr_0.92fr] lg:gap-16 xl:gap-24">
        <div className="flex items-center justify-center">
          <div className="flex max-w-[470px] flex-col items-center text-center">
            <p className="font-montserrat text-[17px] font-normal uppercase tracking-[0.42em] text-[#d79a1e] sm:text-[20px]">
              WHY THARANI
            </p>
            <div className="mt-7 h-px w-[120px] bg-[#e0bd73]" />
            <h2 className="mt-7 font-klaristha text-[4.4rem] leading-[0.98] tracking-[-0.03em] text-[#111111] whitespace-pre-line sm:text-[5.4rem] lg:text-[6.25rem]">
              {whyTharani.heading}
            </h2>
            <div className="mt-7 h-px w-[245px] max-w-full bg-[#e0bd73]" />
            <p className="mt-9 max-w-[430px] font-montserrat text-[1.05rem] font-normal leading-[1.42] text-[#1e1e1e] whitespace-pre-line sm:text-[1.15rem] lg:text-[1.3rem]">
              {whyTharani.subtitle}
            </p>
          </div>
        </div>
        <div className="border-t border-[#e0bd73] pt-12 lg:border-l lg:border-t-0 lg:pl-16 lg:pt-0 xl:pl-20">
          {whyTharani.features.map((item, index) => (
            <div
              key={index}
              className={
                index !== whyTharani.features.length - 1
                  ? "mb-10 border-b border-[#e0bd73] pb-10 sm:mb-12 sm:pb-12"
                  : ""
              }
            >
              <h3 className="font-modern-romance text-[2.8rem] leading-[0.95] text-[#4d4d4d] sm:text-[3.2rem] lg:text-[3.65rem]">
                {item.title}
              </h3>
              <p className="mt-5 max-w-[350px] whitespace-pre-line font-montserrat text-[1rem] leading-[1.34] text-[#555555] sm:text-[1.12rem] lg:text-[1.28rem]">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
